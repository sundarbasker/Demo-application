import { Component, OnInit } from '@angular/core';
import { DataServiceService } from 'src/app/service/data-service.service';
import { ThirdOneComponent } from '../third-one/third-one.component';

@Component({
  selector: 'app-first-one',
  templateUrl: './first-one.component.html',
  styleUrls: ['./first-one.component.css']
})
export class FirstOneComponent implements OnInit {

  constructor(private dataService : DataServiceService) { }


  fullList = [];
  
  ngOnInit() {
// debugger;

    this.dataService.getData().subscribe(
      data => { 
           this.fullList = data;
     console.log(this.fullList);
    });
  }

}


