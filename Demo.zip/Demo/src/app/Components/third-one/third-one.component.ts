import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-third-one',
  templateUrl: './third-one.component.html',
  styleUrls: ['./third-one.component.css']
})
export class ThirdOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
