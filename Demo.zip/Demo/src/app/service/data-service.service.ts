import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment.prod';

@Injectable({
  providedIn: 'root'
})
export class DataServiceService {

  constructor(private http : HttpClient) { }

  getData(): Observable<any> {
  
    // return this.http.get(environment.filterDetail);
    return this.http.get("http://dummy.restapiexample.com/api/v1/employees");
  }

}
